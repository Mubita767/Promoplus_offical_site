// PromoPulse About Page JavaScript
document.addEventListener("DOMContentLoaded", function () {
  // Testimonial Slider Functionality
  const testimonials = document.querySelectorAll(".pps-about-testimonial");
  const dots = document.querySelectorAll(".pps-about-testimonial-dots .dot");
  const prevBtn = document.querySelector(".pps-about-testimonial-prev");
  const nextBtn = document.querySelector(".pps-about-testimonial-next");
  let currentIndex = 0;

  // Show specific testimonial
  function showTestimonial(index) {
    testimonials.forEach((testimonial) =>
      testimonial.classList.remove("active")
    );
    dots.forEach((dot) => dot.classList.remove("active"));

    testimonials[index].classList.add("active");
    dots[index].classList.add("active");
    currentIndex = index;
  }

  // Next testimonial
  function nextTestimonial() {
    let newIndex = (currentIndex + 1) % testimonials.length;
    showTestimonial(newIndex);
  }

  // Previous testimonial
  function prevTestimonial() {
    let newIndex =
      (currentIndex - 1 + testimonials.length) % testimonials.length;
    showTestimonial(newIndex);
  }

  // Event Listeners
  nextBtn.addEventListener("click", nextTestimonial);
  prevBtn.addEventListener("click", prevTestimonial);

  // Dot navigation
  dots.forEach((dot, index) => {
    dot.addEventListener("click", () => showTestimonial(index));
  });

  // Auto-rotate testimonials
  let testimonialInterval = setInterval(nextTestimonial, 7000);

  // Pause auto-rotation when hovering over testimonials
  const testimonialSlider = document.querySelector(
    ".pps-about-testimonial-slider"
  );
  testimonialSlider.addEventListener("mouseenter", () => {
    clearInterval(testimonialInterval);
  });

  testimonialSlider.addEventListener("mouseleave", () => {
    testimonialInterval = setInterval(nextTestimonial, 7000);
  });

  // Team member hover effect enhancement
  const teamMembers = document.querySelectorAll(".pps-about-team-member");
  teamMembers.forEach((member) => {
    member.addEventListener("mouseenter", () => {
      const img = member.querySelector(".pps-about-team-img");
      img.style.transform = "scale(1.05)";
    });

    member.addEventListener("mouseleave", () => {
      const img = member.querySelector(".pps-about-team-img");
      img.style.transform = "scale(1)";
    });
  });

  // Value card animation
  const valueCards = document.querySelectorAll(".pps-about-value-card");
  valueCards.forEach((card) => {
    card.addEventListener("mouseenter", () => {
      const icon = card.querySelector(".pps-about-value-icon");
      icon.style.transform = "rotate(5deg) scale(1.1)";
    });

    card.addEventListener("mouseleave", () => {
      const icon = card.querySelector(".pps-about-value-icon");
      icon.style.transform = "rotate(0) scale(1)";
    });
  });

  // Differentiator feature animation
  const diffFeatures = document.querySelectorAll(".pps-about-diff-feature");
  diffFeatures.forEach((feature) => {
    feature.addEventListener("mouseenter", () => {
      const icon = feature.querySelector(".pps-about-diff-icon");
      icon.style.transform = "rotate(10deg)";
      icon.style.backgroundColor = "#2C3E50";
    });

    feature.addEventListener("mouseleave", () => {
      const icon = feature.querySelector(".pps-about-diff-icon");
      icon.style.transform = "rotate(0)";
      icon.style.backgroundColor = "#E67E22";
    });
  });
});
